import React from 'react';
import { TrendingUp, TrendingDown, BarChart, PieChart, Activity, Target, Globe, Calendar } from 'lucide-react';

interface AnalyticsProps {
  selectedCurrency: string;
  selectedRegion: string;
}

const Analytics: React.FC<AnalyticsProps> = ({ selectedCurrency, selectedRegion }) => {
  const currencies = {
    USD: { symbol: '$', name: 'US Dollar' },
    EUR: { symbol: '€', name: 'Euro' },
    GBP: { symbol: '£', name: 'British Pound' },
    INR: { symbol: '₹', name: 'Indian Rupee' },
    CAD: { symbol: 'C$', name: 'Canadian Dollar' },
    AUD: { symbol: 'A$', name: 'Australian Dollar' },
    SGD: { symbol: 'S$', name: 'Singapore Dollar' },
    JPY: { symbol: '¥', name: 'Japanese Yen' },
  };

  const regionData = {
    global: {
      fraudTrends: [
        { month: 'Jan', fraud: 245, legitimate: 45678 },
        { month: 'Feb', fraud: 289, legitimate: 52341 },
        { month: 'Mar', fraud: 198, legitimate: 48567 },
        { month: 'Apr', fraud: 334, legitimate: 56789 },
        { month: 'May', fraud: 267, legitimate: 61234 },
        { month: 'Jun', fraud: 201, legitimate: 58901 },
      ],
      geographicData: [
        { region: 'North America', fraud: 245, total: 45678, rate: 0.54 },
        { region: 'Europe', fraud: 189, total: 34567, rate: 0.55 },
        { region: 'Asia Pacific', fraud: 312, total: 67890, rate: 0.46 },
        { region: 'Latin America', fraud: 156, total: 23456, rate: 0.66 },
      ],
    },
    usa: {
      fraudTrends: [
        { month: 'Jan', fraud: 89, legitimate: 18234 },
        { month: 'Feb', fraud: 102, legitimate: 19876 },
        { month: 'Mar', fraud: 76, legitimate: 17654 },
        { month: 'Apr', fraud: 118, legitimate: 21345 },
        { month: 'May', fraud: 95, legitimate: 22567 },
        { month: 'Jun', fraud: 73, legitimate: 20891 },
      ],
      geographicData: [
        { region: 'California', fraud: 89, total: 15678, rate: 0.57 },
        { region: 'New York', fraud: 67, total: 12345, rate: 0.54 },
        { region: 'Texas', fraud: 78, total: 14567, rate: 0.54 },
        { region: 'Florida', fraud: 56, total: 11234, rate: 0.50 },
      ],
    },
    india: {
      fraudTrends: [
        { month: 'Jan', fraud: 67, legitimate: 12345 },
        { month: 'Feb', fraud: 78, legitimate: 14567 },
        { month: 'Mar', fraud: 54, legitimate: 11234 },
        { month: 'Apr', fraud: 89, legitimate: 16789 },
        { month: 'May', fraud: 72, legitimate: 15432 },
        { month: 'Jun', fraud: 61, legitimate: 13876 },
      ],
      geographicData: [
        { region: 'Maharashtra', fraud: 78, total: 12345, rate: 0.63 },
        { region: 'Karnataka', fraud: 56, total: 9876, rate: 0.57 },
        { region: 'Delhi', fraud: 67, total: 11234, rate: 0.60 },
        { region: 'Tamil Nadu', fraud: 45, total: 8765, rate: 0.51 },
      ],
    },
    canada: {
      fraudTrends: [
        { month: 'Jan', fraud: 34, legitimate: 8765 },
        { month: 'Feb', fraud: 41, legitimate: 9876 },
        { month: 'Mar', fraud: 28, legitimate: 7654 },
        { month: 'Apr', fraud: 47, legitimate: 10234 },
        { month: 'May', fraud: 39, legitimate: 9543 },
        { month: 'Jun', fraud: 32, legitimate: 8901 },
      ],
      geographicData: [
        { region: 'Ontario', fraud: 45, total: 7890, rate: 0.57 },
        { region: 'Quebec', fraud: 34, total: 6543, rate: 0.52 },
        { region: 'British Columbia', fraud: 38, total: 7123, rate: 0.53 },
        { region: 'Alberta', fraud: 29, total: 5678, rate: 0.51 },
      ],
    },
    uk: {
      fraudTrends: [
        { month: 'Jan', fraud: 56, legitimate: 9876 },
        { month: 'Feb', fraud: 67, legitimate: 11234 },
        { month: 'Mar', fraud: 43, legitimate: 8765 },
        { month: 'Apr', fraud: 78, legitimate: 12345 },
        { month: 'May', fraud: 61, legitimate: 10987 },
        { month: 'Jun', fraud: 49, legitimate: 9654 },
      ],
      geographicData: [
        { region: 'London', fraud: 67, total: 10234, rate: 0.65 },
        { region: 'Manchester', fraud: 34, total: 6789, rate: 0.50 },
        { region: 'Birmingham', fraud: 45, total: 7890, rate: 0.57 },
        { region: 'Liverpool', fraud: 28, total: 5432, rate: 0.52 },
      ],
    },
    australia: {
      fraudTrends: [
        { month: 'Jan', fraud: 43, legitimate: 7890 },
        { month: 'Feb', fraud: 52, legitimate: 8765 },
        { month: 'Mar', fraud: 36, legitimate: 6543 },
        { month: 'Apr', fraud: 61, legitimate: 9876 },
        { month: 'May', fraud: 48, legitimate: 8234 },
        { month: 'Jun', fraud: 39, legitimate: 7654 },
      ],
      geographicData: [
        { region: 'New South Wales', fraud: 56, total: 8765, rate: 0.64 },
        { region: 'Victoria', fraud: 43, total: 7234, rate: 0.59 },
        { region: 'Queensland', fraud: 38, total: 6789, rate: 0.56 },
        { region: 'Western Australia', fraud: 29, total: 5432, rate: 0.53 },
      ],
    },
    singapore: {
      fraudTrends: [
        { month: 'Jan', fraud: 23, legitimate: 4567 },
        { month: 'Feb', fraud: 28, legitimate: 5234 },
        { month: 'Mar', fraud: 19, legitimate: 3876 },
        { month: 'Apr', fraud: 34, legitimate: 5789 },
        { month: 'May', fraud: 26, legitimate: 4932 },
        { month: 'Jun', fraud: 21, legitimate: 4321 },
      ],
      geographicData: [
        { region: 'Central', fraud: 34, total: 4567, rate: 0.74 },
        { region: 'East', fraud: 23, total: 3456, rate: 0.67 },
        { region: 'West', fraud: 28, total: 3789, rate: 0.74 },
        { region: 'North', fraud: 19, total: 2876, rate: 0.66 },
      ],
    },
    japan: {
      fraudTrends: [
        { month: 'Jan', fraud: 67, legitimate: 11234 },
        { month: 'Feb', fraud: 78, legitimate: 12876 },
        { month: 'Mar', fraud: 54, legitimate: 9876 },
        { month: 'Apr', fraud: 89, legitimate: 14567 },
        { month: 'May', fraud: 72, legitimate: 13234 },
        { month: 'Jun', fraud: 61, legitimate: 11987 },
      ],
      geographicData: [
        { region: 'Tokyo', fraud: 89, total: 12345, rate: 0.72 },
        { region: 'Osaka', fraud: 56, total: 8765, rate: 0.64 },
        { region: 'Kyoto', fraud: 34, total: 5432, rate: 0.63 },
        { region: 'Yokohama', fraud: 45, total: 6789, rate: 0.66 },
      ],
    },
  };

  const currentData = regionData[selectedRegion as keyof typeof regionData] || regionData.global;
  const currencySymbol = currencies[selectedCurrency as keyof typeof currencies]?.symbol || '$';

  const riskDistribution = [
    { risk: 'Low', count: 78, color: 'bg-green-400' },
    { risk: 'Medium', count: 18, color: 'bg-yellow-400' },
    { risk: 'High', count: 4, color: 'bg-red-400' },
  ];

  const kpis = [
    {
      title: 'Detection Accuracy',
      value: '94.7%',
      change: '+2.3%',
      icon: Target,
      color: 'text-green-400',
    },
    {
      title: 'False Positive Rate',
      value: '0.8%',
      change: '-0.3%',
      icon: Activity,
      color: 'text-blue-400',
    },
    {
      title: 'Response Time',
      value: '1.2s',
      change: '-0.4s',
      icon: TrendingDown,
      color: 'text-purple-400',
    },
    {
      title: 'Model Performance',
      value: '98.2%',
      change: '+1.1%',
      icon: BarChart,
      color: 'text-yellow-400',
    },
  ];

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center space-x-2">
          <TrendingUp className="h-6 w-6 text-blue-400" />
          <span>Fraud Detection Analytics</span>
        </h2>
        <div className="flex items-center space-x-4 text-sm text-gray-400">
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4" />
            <span>{selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4" />
            <span>Currency: {selectedCurrency}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {kpis.map((kpi, index) => (
          <div key={index} className="bg-gray-700 rounded-lg p-4 border border-gray-600">
            <div className="flex items-center justify-between mb-2">
              <kpi.icon className={`h-5 w-5 ${kpi.color}`} />
              <span className={`text-sm font-medium ${kpi.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                {kpi.change}
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-1">{kpi.value}</h3>
            <p className="text-gray-400 text-sm">{kpi.title}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Fraud Trends Chart */}
        <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
          <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
            <BarChart className="h-5 w-5 text-blue-400" />
            <span>Fraud Trends ({currencySymbol})</span>
          </h3>
          <div className="space-y-4">
            {currentData.fraudTrends.map((data, index) => (
              <div key={index} className="flex items-center space-x-4">
                <span className="text-sm text-gray-400 w-8">{data.month}</span>
                <div className="flex-1 bg-gray-600 rounded-full h-4 relative">
                  <div
                    className="bg-green-400 rounded-full h-4"
                    style={{ width: `${(data.legitimate / (data.legitimate + data.fraud)) * 100}%` }}
                  ></div>
                  <div
                    className="bg-red-400 rounded-full h-4 absolute top-0 right-0"
                    style={{ width: `${(data.fraud / (data.legitimate + data.fraud)) * 100}%` }}
                  ></div>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <span className="text-green-400">{data.legitimate.toLocaleString()}</span>
                  <span className="text-red-400">{data.fraud}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
              <span className="text-gray-400">Legitimate</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
              <span className="text-gray-400">Fraud</span>
            </div>
          </div>
        </div>

        {/* Risk Distribution */}
        <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
          <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
            <PieChart className="h-5 w-5 text-purple-400" />
            <span>Risk Distribution</span>
          </h3>
          <div className="space-y-4">
            {riskDistribution.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-4 h-4 rounded-full ${data.color}`}></div>
                  <span className="text-gray-300">{data.risk} Risk</span>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-gray-600 rounded-full h-2 w-20">
                    <div
                      className={`h-2 rounded-full ${data.color}`}
                      style={{ width: `${data.count}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-medium">{data.count}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Geographic Analysis */}
      <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <Globe className="h-5 w-5 text-green-400" />
          <span>Regional Fraud Analysis - {selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()}</span>
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-600">
                <th className="text-left py-3 px-4 text-gray-400">Region</th>
                <th className="text-center py-3 px-4 text-gray-400">Total Transactions</th>
                <th className="text-center py-3 px-4 text-gray-400">Fraud Cases</th>
                <th className="text-center py-3 px-4 text-gray-400">Fraud Rate</th>
                <th className="text-center py-3 px-4 text-gray-400">Trend</th>
              </tr>
            </thead>
            <tbody>
              {currentData.geographicData.map((region, index) => (
                <tr key={index} className="border-b border-gray-600 hover:bg-gray-600 transition-colors">
                  <td className="py-3 px-4 font-medium text-gray-300">{region.region}</td>
                  <td className="py-3 px-4 text-center text-gray-300">{region.total.toLocaleString()}</td>
                  <td className="py-3 px-4 text-center text-red-400">{region.fraud}</td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      region.rate < 0.5 ? 'bg-green-400 bg-opacity-20 text-green-400' :
                      region.rate < 0.6 ? 'bg-yellow-400 bg-opacity-20 text-yellow-400' :
                      'bg-red-400 bg-opacity-20 text-red-400'
                    }`}>
                      {region.rate.toFixed(2)}%
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    {region.rate < 0.5 ? (
                      <TrendingDown className="h-4 w-4 text-green-400 mx-auto" />
                    ) : (
                      <TrendingUp className="h-4 w-4 text-red-400 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Analytics;