import React, { useState } from 'react';
import { AlertTriangle, Clock, CheckCircle, X, Bell, Filter, Search, Calendar } from 'lucide-react';

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  timestamp: string;
  status: 'active' | 'investigating' | 'resolved';
  transactionId: string;
  amount: number;
  location: string;
  currency: string;
  country: string;
}

interface AlertCenterProps {
  selectedCurrency: string;
  selectedRegion: string;
}

const AlertCenter: React.FC<AlertCenterProps> = ({ selectedCurrency, selectedRegion }) => {
  const currencies = {
    USD: { symbol: '$', rate: 1 },
    EUR: { symbol: '€', rate: 0.85 },
    GBP: { symbol: '£', rate: 0.73 },
    INR: { symbol: '₹', rate: 83.12 },
    CAD: { symbol: 'C$', rate: 1.35 },
    AUD: { symbol: 'A$', rate: 1.52 },
    SGD: { symbol: 'S$', rate: 1.34 },
    JPY: { symbol: '¥', rate: 149.50 },
  };

  const regionAlerts = {
    global: [
      {
        id: 'ALT-001',
        title: 'High-Risk Transaction Detected',
        description: 'Unusual spending pattern detected: Large electronics purchase',
        severity: 'critical' as const,
        timestamp: '2024-01-15T10:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-789012',
        amount: 12500,
        location: 'Los Angeles, CA',
        currency: 'USD',
        country: 'USA',
      },
      {
        id: 'ALT-002',
        title: 'Multiple Failed Authentication Attempts',
        description: '15 failed login attempts from suspicious IP address',
        severity: 'high' as const,
        timestamp: '2024-01-15T09:45:00Z',
        status: 'investigating' as const,
        transactionId: 'TXN-789013',
        amount: 0,
        location: 'Mumbai, India',
        currency: 'INR',
        country: 'India',
      },
      {
        id: 'ALT-003',
        title: 'Velocity Check Triggered',
        description: '5 transactions within 2 minutes from different locations',
        severity: 'high' as const,
        timestamp: '2024-01-15T09:15:00Z',
        status: 'active' as const,
        transactionId: 'TXN-789014',
        amount: 3240,
        location: 'Toronto, Canada',
        currency: 'CAD',
        country: 'Canada',
      },
      {
        id: 'ALT-004',
        title: 'Suspicious Merchant Category',
        description: 'Transaction at high-risk merchant category',
        severity: 'medium' as const,
        timestamp: '2024-01-15T08:30:00Z',
        status: 'resolved' as const,
        transactionId: 'TXN-789015',
        amount: 450,
        location: 'London, UK',
        currency: 'GBP',
        country: 'UK',
      },
    ],
    usa: [
      {
        id: 'ALT-USA-001',
        title: 'Card Testing Attack Detected',
        description: 'Multiple small transactions at gas stations',
        severity: 'critical' as const,
        timestamp: '2024-01-15T11:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-USA-001',
        amount: 1250,
        location: 'New York, NY',
        currency: 'USD',
        country: 'USA',
      },
      {
        id: 'ALT-USA-002',
        title: 'Cross-State Transaction Pattern',
        description: 'Transactions in multiple states within 1 hour',
        severity: 'high' as const,
        timestamp: '2024-01-15T10:15:00Z',
        status: 'investigating' as const,
        transactionId: 'TXN-USA-002',
        amount: 2340,
        location: 'Chicago, IL',
        currency: 'USD',
        country: 'USA',
      },
    ],
    india: [
      {
        id: 'ALT-IND-001',
        title: 'UPI Fraud Pattern Detected',
        description: 'Suspicious UPI transactions with fake merchant IDs',
        severity: 'critical' as const,
        timestamp: '2024-01-15T12:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-IND-001',
        amount: 50000,
        location: 'Mumbai, India',
        currency: 'INR',
        country: 'India',
      },
      {
        id: 'ALT-IND-002',
        title: 'Digital Wallet Compromise',
        description: 'Multiple unauthorized transactions from digital wallet',
        severity: 'high' as const,
        timestamp: '2024-01-15T11:45:00Z',
        status: 'investigating' as const,
        transactionId: 'TXN-IND-002',
        amount: 25000,
        location: 'Bangalore, India',
        currency: 'INR',
        country: 'India',
      },
    ],
    canada: [
      {
        id: 'ALT-CAN-001',
        title: 'Interac E-Transfer Fraud',
        description: 'Suspicious e-transfer patterns detected',
        severity: 'high' as const,
        timestamp: '2024-01-15T13:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-CAN-001',
        amount: 3500,
        location: 'Toronto, Canada',
        currency: 'CAD',
        country: 'Canada',
      },
    ],
    uk: [
      {
        id: 'ALT-UK-001',
        title: 'Contactless Payment Fraud',
        description: 'Multiple contactless payments above normal limits',
        severity: 'medium' as const,
        timestamp: '2024-01-15T14:30:00Z',
        status: 'investigating' as const,
        transactionId: 'TXN-UK-001',
        amount: 850,
        location: 'London, UK',
        currency: 'GBP',
        country: 'UK',
      },
    ],
    australia: [
      {
        id: 'ALT-AUS-001',
        title: 'EFTPOS Skimming Detected',
        description: 'Card details compromised at ATM location',
        severity: 'critical' as const,
        timestamp: '2024-01-15T15:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-AUS-001',
        amount: 2800,
        location: 'Sydney, Australia',
        currency: 'AUD',
        country: 'Australia',
      },
    ],
    singapore: [
      {
        id: 'ALT-SG-001',
        title: 'PayNow Fraud Alert',
        description: 'Suspicious PayNow transactions to unknown recipients',
        severity: 'high' as const,
        timestamp: '2024-01-15T16:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-SG-001',
        amount: 1800,
        location: 'Singapore',
        currency: 'SGD',
        country: 'Singapore',
      },
    ],
    japan: [
      {
        id: 'ALT-JP-001',
        title: 'IC Card Cloning Detected',
        description: 'Duplicate IC card usage at multiple locations',
        severity: 'critical' as const,
        timestamp: '2024-01-15T17:30:00Z',
        status: 'active' as const,
        transactionId: 'TXN-JP-001',
        amount: 45000,
        location: 'Tokyo, Japan',
        currency: 'JPY',
        country: 'Japan',
      },
    ],
  };

  const [alerts, setAlerts] = useState<Alert[]>(regionAlerts[selectedRegion as keyof typeof regionAlerts] || regionAlerts.global);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const currencySymbol = currencies[selectedCurrency as keyof typeof currencies]?.symbol || '$';
  const currencyRate = currencies[selectedCurrency as keyof typeof currencies]?.rate || 1;

  const convertAmount = (amount: number, fromCurrency: string) => {
    if (fromCurrency === selectedCurrency) return amount;
    const baseAmount = amount / (currencies[fromCurrency as keyof typeof currencies]?.rate || 1);
    return Math.round(baseAmount * currencyRate);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-400 bg-opacity-20 border-red-400';
      case 'high': return 'text-orange-400 bg-orange-400 bg-opacity-20 border-orange-400';
      case 'medium': return 'text-yellow-400 bg-yellow-400 bg-opacity-20 border-yellow-400';
      case 'low': return 'text-blue-400 bg-blue-400 bg-opacity-20 border-blue-400';
      default: return 'text-gray-400 bg-gray-400 bg-opacity-20 border-gray-400';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-red-400 bg-red-400 bg-opacity-20';
      case 'investigating': return 'text-yellow-400 bg-yellow-400 bg-opacity-20';
      case 'resolved': return 'text-green-400 bg-green-400 bg-opacity-20';
      default: return 'text-gray-400 bg-gray-400 bg-opacity-20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <AlertTriangle className="h-4 w-4" />;
      case 'investigating': return <Clock className="h-4 w-4" />;
      case 'resolved': return <CheckCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const filteredAlerts = alerts.filter(alert => {
    const matchesFilter = filter === 'all' || alert.status === filter;
    const matchesSearch = alert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         alert.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const updateAlertStatus = (alertId: string, newStatus: 'active' | 'investigating' | 'resolved') => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, status: newStatus } : alert
    ));
  };

  const dismissAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center space-x-2">
          <Bell className="h-6 w-6 text-red-400" />
          <span>Alert Center</span>
        </h2>
        <div className="flex items-center space-x-4 text-sm text-gray-400">
          <span>{selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()} • {selectedCurrency}</span>
          <Calendar className="h-4 w-4" />
          <span>Real-time monitoring</span>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="flex items-center space-x-2 flex-1">
          <Search className="h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search alerts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-gray-400" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
          >
            <option value="all">All Alerts</option>
            <option value="active">Active</option>
            <option value="investigating">Investigating</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Alerts', value: alerts.length, color: 'text-blue-400' },
          { label: 'Active', value: alerts.filter(a => a.status === 'active').length, color: 'text-red-400' },
          { label: 'Investigating', value: alerts.filter(a => a.status === 'investigating').length, color: 'text-yellow-400' },
          { label: 'Resolved', value: alerts.filter(a => a.status === 'resolved').length, color: 'text-green-400' },
        ].map((stat, index) => (
          <div key={index} className="bg-gray-700 rounded-lg p-4 border border-gray-600">
            <div className={`text-2xl font-bold ${stat.color} mb-1`}>{stat.value}</div>
            <div className="text-sm text-gray-400">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.map((alert) => (
          <div
            key={alert.id}
            className={`bg-gray-700 rounded-lg p-6 border ${getSeverityColor(alert.severity)} hover:bg-gray-600 transition-all duration-200`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <div className={`p-2 rounded-lg ${getSeverityColor(alert.severity)}`}>
                  <AlertTriangle className="h-5 w-5" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="text-lg font-semibold text-white">{alert.title}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(alert.severity)}`}>
                      {alert.severity.toUpperCase()}
                    </span>
                  </div>
                  
                  <p className="text-gray-300 mb-3">{alert.description}</p>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span><strong>ID:</strong> {alert.transactionId}</span>
                    {alert.amount > 0 && (
                      <span><strong>Amount:</strong> {currencySymbol}{convertAmount(alert.amount, alert.currency).toLocaleString()}</span>
                    )}
                    <span><strong>Location:</strong> {alert.location}</span>
                    <span><strong>Country:</strong> {alert.country}</span>
                    <span><strong>Time:</strong> {new Date(alert.timestamp).toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 ml-4">
                <div className={`flex items-center space-x-1 px-2 py-1 rounded-full ${getStatusColor(alert.status)}`}>
                  {getStatusIcon(alert.status)}
                  <span className="text-xs font-medium">
                    {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                  </span>
                </div>
                <button
                  onClick={() => dismissAlert(alert.id)}
                  className="text-gray-400 hover:text-red-400 transition-colors"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-gray-600">
              {alert.status === 'active' && (
                <button
                  onClick={() => updateAlertStatus(alert.id, 'investigating')}
                  className="bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded-lg text-sm transition-colors"
                >
                  Start Investigation
                </button>
              )}
              {alert.status === 'investigating' && (
                <button
                  onClick={() => updateAlertStatus(alert.id, 'resolved')}
                  className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm transition-colors"
                >
                  Mark Resolved
                </button>
              )}
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AlertCenter;