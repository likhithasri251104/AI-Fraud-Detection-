import React, { useState } from 'react';
import { Shield, TrendingUp, AlertCircle, CheckCircle, Activity, Target, Brain, Zap } from 'lucide-react';

interface RiskScoringProps {
  selectedCurrency: string;
  selectedRegion: string;
}

const RiskScoring: React.FC<RiskScoringProps> = ({ selectedCurrency, selectedRegion }) => {
  const [selectedModel, setSelectedModel] = useState('ensemble');

  const currencies = {
    USD: { symbol: '$' },
    EUR: { symbol: '€' },
    GBP: { symbol: '£' },
    INR: { symbol: '₹' },
    CAD: { symbol: 'C$' },
    AUD: { symbol: 'A$' },
    SGD: { symbol: 'S$' },
    JPY: { symbol: '¥' },
  };

  const models = [
    {
      id: 'ensemble',
      name: 'Ensemble Model',
      accuracy: 94.7,
      precision: 92.3,
      recall: 89.1,
      f1Score: 90.7,
      status: 'active',
    },
    {
      id: 'neural_network',
      name: 'Neural Network',
      accuracy: 91.2,
      precision: 88.7,
      recall: 85.4,
      f1Score: 87.0,
      status: 'active',
    },
    {
      id: 'random_forest',
      name: 'Random Forest',
      accuracy: 89.6,
      precision: 86.3,
      recall: 84.1,
      f1Score: 85.2,
      status: 'backup',
    },
    {
      id: 'gradient_boost',
      name: 'Gradient Boosting',
      accuracy: 88.9,
      precision: 85.7,
      recall: 82.9,
      f1Score: 84.3,
      status: 'backup',
    },
  ];

  const regionRiskFactors = {
    global: [
      { factor: 'Transaction Amount', weight: 0.25, description: 'Unusual transaction amounts compared to user history', impact: 'high' },
      { factor: 'Geographic Location', weight: 0.20, description: 'Transactions from unexpected or high-risk locations', impact: 'high' },
      { factor: 'Transaction Velocity', weight: 0.18, description: 'Frequency and timing of transactions', impact: 'medium' },
      { factor: 'Merchant Category', weight: 0.15, description: 'Risk associated with merchant type and category', impact: 'medium' },
      { factor: 'Device/IP History', weight: 0.12, description: 'Known devices and IP addresses for the user', impact: 'low' },
      { factor: 'Time of Day', weight: 0.10, description: 'Unusual transaction times for the user', impact: 'low' },
    ],
    usa: [
      { factor: 'Cross-State Activity', weight: 0.28, description: 'Transactions across multiple states in short time', impact: 'high' },
      { factor: 'Transaction Amount', weight: 0.22, description: 'Large purchases compared to spending history', impact: 'high' },
      { factor: 'Card Present/Not Present', weight: 0.18, description: 'Online vs in-person transaction patterns', impact: 'medium' },
      { factor: 'ZIP Code Mismatch', weight: 0.15, description: 'Billing vs transaction location mismatch', impact: 'medium' },
      { factor: 'Merchant Risk Score', weight: 0.12, description: 'Historical fraud rates at merchant', impact: 'low' },
      { factor: 'Weekend/Holiday Activity', weight: 0.05, description: 'Unusual timing patterns', impact: 'low' },
    ],
    india: [
      { factor: 'UPI Transaction Pattern', weight: 0.30, description: 'Unusual UPI payment patterns and frequencies', impact: 'high' },
      { factor: 'Mobile Number Verification', weight: 0.25, description: 'Mobile OTP and verification patterns', impact: 'high' },
      { factor: 'Digital Wallet Usage', weight: 0.20, description: 'Paytm, PhonePe, Google Pay transaction patterns', impact: 'medium' },
      { factor: 'IFSC Code Validation', weight: 0.15, description: 'Bank routing and transfer validation', impact: 'medium' },
      { factor: 'Regional Language Preference', weight: 0.07, description: 'Language settings and regional patterns', impact: 'low' },
      { factor: 'Festival Season Activity', weight: 0.03, description: 'Seasonal spending pattern analysis', impact: 'low' },
    ],
    canada: [
      { factor: 'Interac E-Transfer Pattern', weight: 0.28, description: 'Email money transfer fraud patterns', impact: 'high' },
      { factor: 'Cross-Province Activity', weight: 0.24, description: 'Transactions across provinces', impact: 'high' },
      { factor: 'Currency Exchange Rate', weight: 0.18, description: 'CAD/USD exchange rate arbitrage', impact: 'medium' },
      { factor: 'Chip and PIN Usage', weight: 0.15, description: 'EMV chip transaction validation', impact: 'medium' },
      { factor: 'Tim Hortons Index', weight: 0.10, description: 'Canadian-specific merchant patterns', impact: 'low' },
      { factor: 'Winter Activity Pattern', weight: 0.05, description: 'Seasonal transaction patterns', impact: 'low' },
    ],
    uk: [
      { factor: 'Contactless Limit Breach', weight: 0.30, description: 'Transactions above contactless limits', impact: 'high' },
      { factor: 'Open Banking Data', weight: 0.25, description: 'Account aggregation and spending patterns', impact: 'high' },
      { factor: 'Faster Payments Risk', weight: 0.20, description: 'Real-time payment fraud patterns', impact: 'medium' },
      { factor: 'Postcode Risk Score', weight: 0.15, description: 'Geographic risk based on postcode', impact: 'medium' },
      { factor: 'Pub/Restaurant Pattern', weight: 0.07, description: 'UK-specific merchant category analysis', impact: 'low' },
      { factor: 'Brexit Impact Factor', weight: 0.03, description: 'Economic uncertainty patterns', impact: 'low' },
    ],
    australia: [
      { factor: 'EFTPOS vs Credit Usage', weight: 0.28, description: 'Payment method preference analysis', impact: 'high' },
      { factor: 'Interstate Transaction', weight: 0.24, description: 'Cross-state transaction patterns', impact: 'high' },
      { factor: 'PayID Verification', weight: 0.20, description: 'Real-time payment identifier validation', impact: 'medium' },
      { factor: 'Mining Town Activity', weight: 0.15, description: 'High-income remote area patterns', impact: 'medium' },
      { factor: 'Woolworths/Coles Pattern', weight: 0.08, description: 'Major retailer spending patterns', impact: 'low' },
      { factor: 'Bushfire Season Impact', weight: 0.05, description: 'Emergency spending pattern analysis', impact: 'low' },
    ],
    singapore: [
      { factor: 'PayNow Transaction Risk', weight: 0.32, description: 'Real-time payment fraud detection', impact: 'high' },
      { factor: 'NRIC Validation', weight: 0.28, description: 'National ID verification patterns', impact: 'high' },
      { factor: 'Hawker Center Spending', weight: 0.18, description: 'Cash vs digital payment patterns', impact: 'medium' },
      { factor: 'Cross-Border Activity', weight: 0.12, description: 'Malaysia/Indonesia transaction patterns', impact: 'medium' },
      { factor: 'HDB vs Condo Pattern', weight: 0.07, description: 'Residential area spending patterns', impact: 'low' },
      { factor: 'CNY Shopping Pattern', weight: 0.03, description: 'Chinese New Year spending analysis', impact: 'low' },
    ],
    japan: [
      { factor: 'IC Card Cloning Risk', weight: 0.30, description: 'Suica/Pasmo card fraud detection', impact: 'high' },
      { factor: 'Convenience Store Pattern', weight: 0.25, description: '7-Eleven, Lawson, FamilyMart analysis', impact: 'high' },
      { factor: 'Cash vs Digital Ratio', weight: 0.20, description: 'Japan\'s cash-heavy society patterns', impact: 'medium' },
      { factor: 'Pachinko Parlor Activity', weight: 0.15, description: 'Gaming establishment transaction patterns', impact: 'medium' },
      { factor: 'Kanji Input Pattern', weight: 0.07, description: 'Japanese character input validation', impact: 'low' },
      { factor: 'Golden Week Activity', weight: 0.03, description: 'Holiday season spending patterns', impact: 'low' },
    ],
  };

  const recentScores = [
    { transactionId: 'TXN-001', score: 95, risk: 'High', factors: ['Amount', 'Location'] },
    { transactionId: 'TXN-002', score: 23, risk: 'Low', factors: ['Normal pattern'] },
    { transactionId: 'TXN-003', score: 67, risk: 'Medium', factors: ['Velocity', 'Time'] },
    { transactionId: 'TXN-004', score: 89, risk: 'High', factors: ['Amount', 'Merchant'] },
    { transactionId: 'TXN-005', score: 15, risk: 'Low', factors: ['Known device'] },
  ];

  const currentRiskFactors = regionRiskFactors[selectedRegion as keyof typeof regionRiskFactors] || regionRiskFactors.global;
  const currencySymbol = currencies[selectedCurrency as keyof typeof currencies]?.symbol || '$';

  const getRiskColor = (risk: string) => {
    switch (risk.toLowerCase()) {
      case 'high': return 'text-red-400 bg-red-400 bg-opacity-20';
      case 'medium': return 'text-yellow-400 bg-yellow-400 bg-opacity-20';
      case 'low': return 'text-green-400 bg-green-400 bg-opacity-20';
      default: return 'text-gray-400 bg-gray-400 bg-opacity-20';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-green-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center space-x-2">
          <Shield className="h-6 w-6 text-blue-400" />
          <span>Risk Scoring Engine</span>
        </h2>
        <div className="flex items-center space-x-4 text-sm text-gray-400">
          <span>{selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()} • {selectedCurrency}</span>
          <Brain className="h-4 w-4" />
          <span>AI-Powered</span>
        </div>
      </div>

      {/* Model Performance Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
          <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
            <Target className="h-5 w-5 text-purple-400" />
            <span>Active Models</span>
          </h3>
          <div className="space-y-4">
            {models.map((model) => (
              <div
                key={model.id}
                className={`p-4 rounded-lg border transition-all cursor-pointer ${
                  selectedModel === model.id
                    ? 'border-blue-500 bg-blue-500 bg-opacity-10'
                    : 'border-gray-600 hover:border-gray-500'
                }`}
                onClick={() => setSelectedModel(model.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">{model.name}</h4>
                  <div className="flex items-center space-x-2">
                    {model.status === 'active' ? (
                      <div className="flex items-center space-x-1 text-green-400">
                        <CheckCircle className="h-4 w-4" />
                        <span className="text-xs">Active</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-1 text-gray-400">
                        <AlertCircle className="h-4 w-4" />
                        <span className="text-xs">Backup</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Accuracy:</span>
                    <span className="text-white ml-2">{model.accuracy}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Precision:</span>
                    <span className="text-white ml-2">{model.precision}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">Recall:</span>
                    <span className="text-white ml-2">{model.recall}%</span>
                  </div>
                  <div>
                    <span className="text-gray-400">F1-Score:</span>
                    <span className="text-white ml-2">{model.f1Score}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
          <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
            <Activity className="h-5 w-5 text-green-400" />
            <span>Risk Factor Weights - {selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()}</span>
          </h3>
          <div className="space-y-4">
            {currentRiskFactors.map((factor, index) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-white font-medium">{factor.factor}</span>
                  <div className="flex items-center space-x-2">
                    <span className={`text-sm ${getImpactColor(factor.impact)}`}>
                      {factor.impact}
                    </span>
                    <span className="text-sm text-gray-400">
                      {(factor.weight * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
                <div className="bg-gray-600 rounded-full h-2">
                  <div
                    className="bg-blue-400 rounded-full h-2 transition-all duration-500"
                    style={{ width: `${factor.weight * 100}%` }}
                  ></div>
                </div>
                <p className="text-xs text-gray-400">{factor.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Risk Scores */}
      <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <Zap className="h-5 w-5 text-yellow-400" />
          <span>Recent Risk Scores ({currencySymbol})</span>
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-600">
                <th className="text-left py-3 px-4 text-gray-400">Transaction ID</th>
                <th className="text-center py-3 px-4 text-gray-400">Risk Score</th>
                <th className="text-center py-3 px-4 text-gray-400">Risk Level</th>
                <th className="text-left py-3 px-4 text-gray-400">Key Factors</th>
                <th className="text-center py-3 px-4 text-gray-400">Action</th>
              </tr>
            </thead>
            <tbody>
              {recentScores.map((score, index) => (
                <tr key={index} className="border-b border-gray-600 hover:bg-gray-600 transition-colors">
                  <td className="py-3 px-4 font-medium text-gray-300">{score.transactionId}</td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-16 bg-gray-600 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            score.score >= 70 ? 'bg-red-400' :
                            score.score >= 40 ? 'bg-yellow-400' : 'bg-green-400'
                          }`}
                          style={{ width: `${score.score}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{score.score}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(score.risk)}`}>
                      {score.risk}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex flex-wrap gap-1">
                      {score.factors.map((factor, idx) => (
                        <span
                          key={idx}
                          className="bg-gray-600 text-gray-300 px-2 py-1 rounded text-xs"
                        >
                          {factor}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button className="text-blue-400 hover:text-blue-300 text-sm">
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RiskScoring;