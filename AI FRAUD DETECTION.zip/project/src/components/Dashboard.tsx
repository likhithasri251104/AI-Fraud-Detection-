import React, { useState, useEffect } from 'react';
import { AlertTriangle, Shield, TrendingUp, Users, DollarSign, MapPin, Clock, Filter, Globe } from 'lucide-react';
import TransactionMonitor from './TransactionMonitor';
import Analytics from './Analytics';
import AlertCenter from './AlertCenter';
import RiskScoring from './RiskScoring';
import PatternAnalysis from './PatternAnalysis';

const Dashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('monitor');
  const [alerts, setAlerts] = useState(23);
  const [riskLevel, setRiskLevel] = useState('Medium');
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [selectedRegion, setSelectedRegion] = useState('global');

  const currencies = [
    { code: 'USD', symbol: '$', name: 'US Dollar' },
    { code: 'EUR', symbol: '€', name: 'Euro' },
    { code: 'GBP', symbol: '£', name: 'British Pound' },
    { code: 'INR', symbol: '₹', name: 'Indian Rupee' },
    { code: 'CAD', symbol: 'C$', name: 'Canadian Dollar' },
    { code: 'AUD', symbol: 'A$', name: 'Australian Dollar' },
    { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar' },
    { code: 'JPY', symbol: '¥', name: 'Japanese Yen' },
  ];

  const regions = [
    { code: 'global', name: 'Global', flag: '🌍' },
    { code: 'usa', name: 'United States', flag: '🇺🇸' },
    { code: 'india', name: 'India', flag: '🇮🇳' },
    { code: 'canada', name: 'Canada', flag: '🇨🇦' },
    { code: 'uk', name: 'United Kingdom', flag: '🇬🇧' },
    { code: 'australia', name: 'Australia', flag: '🇦🇺' },
    { code: 'singapore', name: 'Singapore', flag: '🇸🇬' },
    { code: 'japan', name: 'Japan', flag: '🇯🇵' },
  ];

  const tabs = [
    { id: 'monitor', label: 'Live Monitor', icon: Clock },
    { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    { id: 'alerts', label: 'Alerts', icon: AlertTriangle },
    { id: 'risk', label: 'Risk Scoring', icon: Shield },
    { id: 'patterns', label: 'Pattern Analysis', icon: Filter },
  ];

  const stats = [
    {
      title: 'Total Transactions',
      value: '1,247,892',
      change: '+12.5%',
      icon: DollarSign,
      color: 'bg-blue-500',
    },
    {
      title: 'Fraud Detected',
      value: '1,432',
      change: '-8.2%',
      icon: AlertTriangle,
      color: 'bg-red-500',
    },
    {
      title: 'Risk Score',
      value: '72/100',
      change: '+2.1%',
      icon: Shield,
      color: 'bg-yellow-500',
    },
    {
      title: 'Active Users',
      value: '847,293',
      change: '+5.7%',
      icon: Users,
      color: 'bg-green-500',
    },
  ];

  const selectedCurrencyData = currencies.find(c => c.code === selectedCurrency);
  const selectedRegionData = regions.find(r => r.code === selectedRegion);

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-blue-400" />
              <h1 className="text-2xl font-bold">FraudGuard AI</h1>
            </div>
            <div className="flex items-center space-x-2 bg-gray-700 px-3 py-1 rounded-full">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="text-sm">System Active</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Currency Selector */}
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-gray-400" />
              <select
                value={selectedCurrency}
                onChange={(e) => setSelectedCurrency(e.target.value)}
                className="bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none text-sm"
              >
                {currencies.map((currency) => (
                  <option key={currency.code} value={currency.code}>
                    {currency.symbol} {currency.code} - {currency.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Region Selector */}
            <div className="flex items-center space-x-2">
              <Globe className="h-4 w-4 text-gray-400" />
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none text-sm"
              >
                {regions.map((region) => (
                  <option key={region.code} value={region.code}>
                    {region.flag} {region.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-medium">
              Risk: {riskLevel}
            </div>
          </div>
        </div>

        {/* Region & Currency Info Bar */}
        <div className="mt-3 flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4 text-gray-400">
            <span>Monitoring: {selectedRegionData?.flag} {selectedRegionData?.name}</span>
            <span>•</span>
            <span>Currency: {selectedCurrencyData?.symbol} {selectedCurrencyData?.name}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-400">
            <MapPin className="h-4 w-4" />
            <span>Real-time Global Coverage</span>
          </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="px-6 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-300">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.color} bg-opacity-20`}>
                  <stat.icon className={`h-6 w-6 ${stat.color.replace('bg-', 'text-')}`} />
                </div>
                <span className={`text-sm font-medium ${stat.change.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                  {stat.change}
                </span>
              </div>
              <h3 className="text-3xl font-bold mb-1">{stat.value}</h3>
              <p className="text-gray-400 text-sm">{stat.title}</p>
            </div>
          ))}
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-8 bg-gray-800 p-1 rounded-xl">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-700'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.label}</span>
              {tab.id === 'alerts' && alerts > 0 && (
                <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {alerts}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="bg-gray-800 rounded-xl border border-gray-700">
          {activeTab === 'monitor' && <TransactionMonitor selectedCurrency={selectedCurrency} selectedRegion={selectedRegion} />}
          {activeTab === 'analytics' && <Analytics selectedCurrency={selectedCurrency} selectedRegion={selectedRegion} />}
          {activeTab === 'alerts' && <AlertCenter selectedCurrency={selectedCurrency} selectedRegion={selectedRegion} />}
          {activeTab === 'risk' && <RiskScoring selectedCurrency={selectedCurrency} selectedRegion={selectedRegion} />}
          {activeTab === 'patterns' && <PatternAnalysis selectedCurrency={selectedCurrency} selectedRegion={selectedRegion} />}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;