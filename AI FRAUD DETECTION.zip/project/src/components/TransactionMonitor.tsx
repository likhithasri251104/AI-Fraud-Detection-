import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Clock, DollarSign, MapPin, User, CreditCard, Zap } from 'lucide-react';

interface Transaction {
  id: string;
  amount: number;
  currency: string;
  merchant: string;
  location: string;
  timestamp: string;
  riskScore: number;
  status: 'safe' | 'suspicious' | 'flagged';
  cardType: string;
  userId: string;
  ipAddress: string;
  country: string;
}

interface TransactionMonitorProps {
  selectedCurrency: string;
  selectedRegion: string;
}

const TransactionMonitor: React.FC<TransactionMonitorProps> = ({ selectedCurrency, selectedRegion }) => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filter, setFilter] = useState('all');

  const currencies = {
    USD: { symbol: '$', rate: 1 },
    EUR: { symbol: '€', rate: 0.85 },
    GBP: { symbol: '£', rate: 0.73 },
    INR: { symbol: '₹', rate: 83.12 },
    CAD: { symbol: 'C$', rate: 1.35 },
    AUD: { symbol: 'A$', rate: 1.52 },
    SGD: { symbol: 'S$', rate: 1.34 },
    JPY: { symbol: '¥', rate: 149.50 },
  };

  const locations = {
    global: [
      { city: 'New York', country: 'USA', flag: '🇺🇸' },
      { city: 'Mumbai', country: 'India', flag: '🇮🇳' },
      { city: 'Toronto', country: 'Canada', flag: '🇨🇦' },
      { city: 'London', country: 'UK', flag: '🇬🇧' },
      { city: 'Sydney', country: 'Australia', flag: '🇦🇺' },
      { city: 'Singapore', country: 'Singapore', flag: '🇸🇬' },
      { city: 'Tokyo', country: 'Japan', flag: '🇯🇵' },
    ],
    usa: [
      { city: 'New York', country: 'USA', flag: '🇺🇸' },
      { city: 'Los Angeles', country: 'USA', flag: '🇺🇸' },
      { city: 'Chicago', country: 'USA', flag: '🇺🇸' },
      { city: 'Houston', country: 'USA', flag: '🇺🇸' },
      { city: 'Phoenix', country: 'USA', flag: '🇺🇸' },
      { city: 'Philadelphia', country: 'USA', flag: '🇺🇸' },
    ],
    india: [
      { city: 'Mumbai', country: 'India', flag: '🇮🇳' },
      { city: 'Delhi', country: 'India', flag: '🇮🇳' },
      { city: 'Bangalore', country: 'India', flag: '🇮🇳' },
      { city: 'Hyderabad', country: 'India', flag: '🇮🇳' },
      { city: 'Chennai', country: 'India', flag: '🇮🇳' },
      { city: 'Kolkata', country: 'India', flag: '🇮🇳' },
    ],
    canada: [
      { city: 'Toronto', country: 'Canada', flag: '🇨🇦' },
      { city: 'Vancouver', country: 'Canada', flag: '🇨🇦' },
      { city: 'Montreal', country: 'Canada', flag: '🇨🇦' },
      { city: 'Calgary', country: 'Canada', flag: '🇨🇦' },
      { city: 'Ottawa', country: 'Canada', flag: '🇨🇦' },
      { city: 'Edmonton', country: 'Canada', flag: '🇨🇦' },
    ],
    uk: [
      { city: 'London', country: 'UK', flag: '🇬🇧' },
      { city: 'Manchester', country: 'UK', flag: '🇬🇧' },
      { city: 'Birmingham', country: 'UK', flag: '🇬🇧' },
      { city: 'Liverpool', country: 'UK', flag: '🇬🇧' },
      { city: 'Leeds', country: 'UK', flag: '🇬🇧' },
      { city: 'Glasgow', country: 'UK', flag: '🇬🇧' },
    ],
    australia: [
      { city: 'Sydney', country: 'Australia', flag: '🇦🇺' },
      { city: 'Melbourne', country: 'Australia', flag: '🇦🇺' },
      { city: 'Brisbane', country: 'Australia', flag: '🇦🇺' },
      { city: 'Perth', country: 'Australia', flag: '🇦🇺' },
      { city: 'Adelaide', country: 'Australia', flag: '🇦🇺' },
      { city: 'Canberra', country: 'Australia', flag: '🇦🇺' },
    ],
    singapore: [
      { city: 'Singapore', country: 'Singapore', flag: '🇸🇬' },
      { city: 'Jurong', country: 'Singapore', flag: '🇸🇬' },
      { city: 'Tampines', country: 'Singapore', flag: '🇸🇬' },
      { city: 'Woodlands', country: 'Singapore', flag: '🇸🇬' },
    ],
    japan: [
      { city: 'Tokyo', country: 'Japan', flag: '🇯🇵' },
      { city: 'Osaka', country: 'Japan', flag: '🇯🇵' },
      { city: 'Kyoto', country: 'Japan', flag: '🇯🇵' },
      { city: 'Yokohama', country: 'Japan', flag: '🇯🇵' },
      { city: 'Nagoya', country: 'Japan', flag: '🇯🇵' },
      { city: 'Sapporo', country: 'Japan', flag: '🇯🇵' },
    ],
  };

  const merchants = {
    global: ['Amazon', 'Walmart', 'Target', 'Best Buy', 'Apple Store', 'McDonald\'s', 'Starbucks', 'Shell'],
    usa: ['Walmart', 'Target', 'Best Buy', 'Home Depot', 'CVS Pharmacy', 'Walgreens', 'McDonald\'s'],
    india: ['Reliance Digital', 'Big Bazaar', 'Flipkart', 'Swiggy', 'Zomato', 'BookMyShow', 'Paytm Mall'],
    canada: ['Canadian Tire', 'Loblaws', 'Shoppers Drug Mart', 'Tim Hortons', 'Metro', 'Costco Canada'],
    uk: ['Tesco', 'ASDA', 'Sainsbury\'s', 'Marks & Spencer', 'John Lewis', 'Boots', 'Costa Coffee'],
    australia: ['Woolworths', 'Coles', 'JB Hi-Fi', 'Harvey Norman', 'Bunnings', 'Chemist Warehouse'],
    singapore: ['NTUC FairPrice', 'Cold Storage', 'Courts', 'Popular Bookstore', 'Guardian', 'Watsons'],
    japan: ['7-Eleven', 'Lawson', 'FamilyMart', 'Don Quijote', 'Uniqlo', 'Muji', 'Yodobashi Camera'],
  };

  useEffect(() => {
    const generateTransaction = (): Transaction => {
      const regionLocations = locations[selectedRegion as keyof typeof locations] || locations.global;
      const regionMerchants = merchants[selectedRegion as keyof typeof merchants] || merchants.global;
      const cardTypes = ['Visa', 'Mastercard', 'American Express', 'Discover'];
      const statuses: ('safe' | 'suspicious' | 'flagged')[] = ['safe', 'safe', 'safe', 'suspicious', 'flagged'];
      
      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const riskScore = status === 'safe' ? Math.random() * 30 : 
                       status === 'suspicious' ? 30 + Math.random() * 40 : 
                       70 + Math.random() * 30;

      const location = regionLocations[Math.floor(Math.random() * regionLocations.length)];
      const baseAmount = Math.floor(Math.random() * 5000) + 10;
      const currencyRate = currencies[selectedCurrency as keyof typeof currencies]?.rate || 1;
      const convertedAmount = Math.round(baseAmount * currencyRate);

      return {
        id: `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        amount: convertedAmount,
        currency: selectedCurrency,
        merchant: regionMerchants[Math.floor(Math.random() * regionMerchants.length)],
        location: `${location.city}, ${location.country}`,
        country: location.country,
        timestamp: new Date().toISOString(),
        riskScore: Math.round(riskScore),
        status,
        cardType: cardTypes[Math.floor(Math.random() * cardTypes.length)],
        userId: `USR-${Math.random().toString(36).substr(2, 6)}`,
        ipAddress: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
      };
    };

    // Add initial transactions
    const initialTransactions = Array.from({ length: 15 }, generateTransaction);
    setTransactions(initialTransactions);

    // Simulate real-time updates
    const interval = setInterval(() => {
      const newTransaction = generateTransaction();
      setTransactions(prev => [newTransaction, ...prev.slice(0, 24)]);
    }, 3000);

    return () => clearInterval(interval);
  }, [selectedCurrency, selectedRegion]);

  const getStatusColor = (status: string, riskScore: number) => {
    switch (status) {
      case 'safe': return 'text-green-400 bg-green-400 bg-opacity-20';
      case 'suspicious': return 'text-yellow-400 bg-yellow-400 bg-opacity-20';
      case 'flagged': return 'text-red-400 bg-red-400 bg-opacity-20';
      default: return 'text-gray-400 bg-gray-400 bg-opacity-20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'safe': return <CheckCircle className="h-4 w-4" />;
      case 'suspicious': return <Clock className="h-4 w-4" />;
      case 'flagged': return <AlertTriangle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const filteredTransactions = transactions.filter(t => 
    filter === 'all' || t.status === filter
  );

  const currencySymbol = currencies[selectedCurrency as keyof typeof currencies]?.symbol || '$';

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <h2 className="text-2xl font-bold">Live Transaction Monitor</h2>
          <div className="flex items-center space-x-2 bg-green-500 bg-opacity-20 text-green-400 px-3 py-1 rounded-full">
            <Zap className="h-4 w-4" />
            <span className="text-sm font-medium">Real-time</span>
          </div>
          <div className="text-sm text-gray-400">
            Showing {selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()} transactions in {selectedCurrency}
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
          >
            <option value="all">All Transactions</option>
            <option value="safe">Safe</option>
            <option value="suspicious">Suspicious</option>
            <option value="flagged">Flagged</option>
          </select>
        </div>
      </div>

      <div className="grid gap-4">
        {filteredTransactions.map((transaction) => (
          <div
            key={transaction.id}
            className="bg-gray-700 rounded-lg p-4 border border-gray-600 hover:border-gray-500 transition-all duration-300 animate-fadeIn"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-lg ${getStatusColor(transaction.status, transaction.riskScore)}`}>
                  {getStatusIcon(transaction.status)}
                </div>
                
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <DollarSign className="h-4 w-4 text-green-400" />
                    <span className="text-xl font-bold">
                      {currencySymbol}{transaction.amount.toLocaleString()}
                    </span>
                    <span className="text-gray-400">{transaction.currency}</span>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <User className="h-3 w-3" />
                      <span>{transaction.userId}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <CreditCard className="h-3 w-3" />
                      <span>{transaction.cardType}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-3 w-3" />
                      <span>{transaction.location}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm text-gray-400">Risk Score:</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-20 bg-gray-600 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${
                          transaction.riskScore < 30 ? 'bg-green-400' :
                          transaction.riskScore < 70 ? 'bg-yellow-400' : 'bg-red-400'
                        }`}
                        style={{ width: `${transaction.riskScore}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium">{transaction.riskScore}</span>
                  </div>
                </div>
                <div className="text-sm text-gray-400">
                  {new Date(transaction.timestamp).toLocaleTimeString()}
                </div>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-gray-600">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-4">
                  <span className="text-gray-300">
                    <strong>Merchant:</strong> {transaction.merchant}
                  </span>
                  <span className="text-gray-300">
                    <strong>IP:</strong> {transaction.ipAddress}
                  </span>
                  <span className="text-gray-300">
                    <strong>Country:</strong> {transaction.country}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(transaction.status, transaction.riskScore)}`}>
                    {transaction.status.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransactionMonitor;