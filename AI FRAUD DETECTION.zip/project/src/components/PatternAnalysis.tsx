import React, { useState } from 'react';
import { Filter, Search, TrendingUp, Users, MapPin, Clock, AlertTriangle, Eye } from 'lucide-react';

interface PatternAnalysisProps {
  selectedCurrency: string;
  selectedRegion: string;
}

const PatternAnalysis: React.FC<PatternAnalysisProps> = ({ selectedCurrency, selectedRegion }) => {
  const [selectedPattern, setSelectedPattern] = useState('velocity');
  const [timeRange, setTimeRange] = useState('7d');

  const currencies = {
    USD: { symbol: '$' },
    EUR: { symbol: '€' },
    GBP: { symbol: '£' },
    INR: { symbol: '₹' },
    CAD: { symbol: 'C$' },
    AUD: { symbol: 'A$' },
    SGD: { symbol: 'S$' },
    JPY: { symbol: '¥' },
  };

  const patterns = [
    {
      id: 'velocity',
      name: 'Velocity Patterns',
      description: 'Unusual transaction frequency and timing',
      detectedCases: 245,
      accuracy: 91.2,
      icon: TrendingUp,
    },
    {
      id: 'geographic',
      name: 'Geographic Anomalies',
      description: 'Impossible travel and location patterns',
      detectedCases: 178,
      accuracy: 94.7,
      icon: MapPin,
    },
    {
      id: 'behavioral',
      name: 'Behavioral Patterns',
      description: 'Deviations from normal user behavior',
      detectedCases: 312,
      accuracy: 88.9,
      icon: Users,
    },
    {
      id: 'temporal',
      name: 'Temporal Anomalies',
      description: 'Unusual timing and sequence patterns',
      detectedCases: 156,
      accuracy: 92.3,
      icon: Clock,
    },
  ];

  const regionPatterns = {
    global: {
      velocity: [
        {
          id: 'VEL-001',
          title: 'Card Testing Attack',
          description: '50+ small transactions in 5 minutes',
          severity: 'high',
          transactions: 52,
          timeWindow: '5 minutes',
          locations: ['New York, NY'],
          riskScore: 95,
        },
        {
          id: 'VEL-002',
          title: 'Rapid Fire Transactions',
          description: 'Multiple high-value transactions',
          severity: 'critical',
          transactions: 8,
          timeWindow: '2 minutes',
          locations: ['Los Angeles, CA', 'Chicago, IL'],
          riskScore: 98,
        },
      ],
      geographic: [
        {
          id: 'GEO-001',
          title: 'Impossible Travel',
          description: 'Transactions 3000 miles apart in 1 hour',
          severity: 'critical',
          transactions: 2,
          timeWindow: '1 hour',
          locations: ['New York, NY', 'Los Angeles, CA'],
          riskScore: 99,
        },
      ],
      behavioral: [
        {
          id: 'BEH-001',
          title: 'Spending Pattern Anomaly',
          description: 'Luxury purchases vs. normal spending',
          severity: 'high',
          transactions: 3,
          timeWindow: '1 day',
          locations: ['Miami, FL'],
          riskScore: 87,
        },
      ],
      temporal: [
        {
          id: 'TEM-001',
          title: 'Off-Hours Activity',
          description: 'Transactions during unusual hours',
          severity: 'medium',
          transactions: 7,
          timeWindow: '2-4 AM',
          locations: ['Dallas, TX'],
          riskScore: 68,
        },
      ],
    },
    usa: {
      velocity: [
        {
          id: 'VEL-USA-001',
          title: 'Cross-State Card Testing',
          description: 'Rapid transactions across multiple states',
          severity: 'critical',
          transactions: 45,
          timeWindow: '10 minutes',
          locations: ['California', 'Nevada', 'Arizona'],
          riskScore: 97,
        },
      ],
      geographic: [
        {
          id: 'GEO-USA-001',
          title: 'Coast-to-Coast Impossible Travel',
          description: 'East to West coast transactions in 2 hours',
          severity: 'critical',
          transactions: 3,
          timeWindow: '2 hours',
          locations: ['New York, NY', 'San Francisco, CA'],
          riskScore: 99,
        },
      ],
      behavioral: [
        {
          id: 'BEH-USA-001',
          title: 'Black Friday Anomaly',
          description: 'Unusual shopping patterns during sales',
          severity: 'medium',
          transactions: 15,
          timeWindow: '1 day',
          locations: ['Multiple US locations'],
          riskScore: 72,
        },
      ],
      temporal: [
        {
          id: 'TEM-USA-001',
          title: 'Business Hours Violation',
          description: 'B2B transactions outside business hours',
          severity: 'medium',
          transactions: 8,
          timeWindow: 'Weekends',
          locations: ['Various US cities'],
          riskScore: 65,
        },
      ],
    },
    india: {
      velocity: [
        {
          id: 'VEL-IND-001',
          title: 'UPI Rapid Fire',
          description: 'Multiple UPI transactions in seconds',
          severity: 'critical',
          transactions: 67,
          timeWindow: '30 seconds',
          locations: ['Mumbai', 'Delhi'],
          riskScore: 96,
        },
      ],
      geographic: [
        {
          id: 'GEO-IND-001',
          title: 'Kashmir to Kanyakumari',
          description: 'Transactions from extreme north to south',
          severity: 'high',
          transactions: 2,
          timeWindow: '3 hours',
          locations: ['Srinagar', 'Kanyakumari'],
          riskScore: 94,
        },
      ],
      behavioral: [
        {
          id: 'BEH-IND-001',
          title: 'Festival Season Anomaly',
          description: 'Unusual Diwali shopping patterns',
          severity: 'medium',
          transactions: 23,
          timeWindow: '2 days',
          locations: ['Multiple Indian cities'],
          riskScore: 78,
        },
      ],
      temporal: [
        {
          id: 'TEM-IND-001',
          title: 'Midnight Digital Wallet',
          description: 'Late night digital wallet transactions',
          severity: 'medium',
          transactions: 12,
          timeWindow: '12-3 AM',
          locations: ['Bangalore', 'Hyderabad'],
          riskScore: 71,
        },
      ],
    },
    canada: {
      velocity: [
        {
          id: 'VEL-CAN-001',
          title: 'Interac E-Transfer Spam',
          description: 'Rapid e-transfer attempts',
          severity: 'high',
          transactions: 34,
          timeWindow: '15 minutes',
          locations: ['Toronto', 'Vancouver'],
          riskScore: 89,
        },
      ],
      geographic: [
        {
          id: 'GEO-CAN-001',
          title: 'Coast-to-Coast Pattern',
          description: 'Atlantic to Pacific transactions',
          severity: 'high',
          transactions: 2,
          timeWindow: '4 hours',
          locations: ['Halifax, NS', 'Vancouver, BC'],
          riskScore: 91,
        },
      ],
      behavioral: [
        {
          id: 'BEH-CAN-001',
          title: 'Winter Spending Anomaly',
          description: 'Unusual winter equipment purchases',
          severity: 'low',
          transactions: 8,
          timeWindow: '1 week',
          locations: ['Calgary', 'Edmonton'],
          riskScore: 45,
        },
      ],
      temporal: [
        {
          id: 'TEM-CAN-001',
          title: 'Hockey Night Transactions',
          description: 'Unusual activity during hockey games',
          severity: 'low',
          transactions: 6,
          timeWindow: 'Saturday nights',
          locations: ['Montreal', 'Toronto'],
          riskScore: 38,
        },
      ],
    },
    uk: {
      velocity: [
        {
          id: 'VEL-UK-001',
          title: 'Contactless Tap Frenzy',
          description: 'Rapid contactless payments',
          severity: 'high',
          transactions: 28,
          timeWindow: '8 minutes',
          locations: ['London Underground stations'],
          riskScore: 88,
        },
      ],
      geographic: [
        {
          id: 'GEO-UK-001',
          title: 'Scotland to Cornwall',
          description: 'Transactions from Scotland to Southwest England',
          severity: 'medium',
          transactions: 2,
          timeWindow: '5 hours',
          locations: ['Edinburgh', 'Cornwall'],
          riskScore: 82,
        },
      ],
      behavioral: [
        {
          id: 'BEH-UK-001',
          title: 'Brexit Panic Buying',
          description: 'Unusual stockpiling behavior',
          severity: 'medium',
          transactions: 18,
          timeWindow: '2 days',
          locations: ['Various UK cities'],
          riskScore: 74,
        },
      ],
      temporal: [
        {
          id: 'TEM-UK-001',
          title: 'Sunday Trading Violation',
          description: 'Large transactions on Sundays',
          severity: 'low',
          transactions: 5,
          timeWindow: 'Sunday mornings',
          locations: ['Birmingham', 'Manchester'],
          riskScore: 42,
        },
      ],
    },
    australia: {
      velocity: [
        {
          id: 'VEL-AUS-001',
          title: 'EFTPOS Rapid Sequence',
          description: 'Multiple EFTPOS transactions rapidly',
          severity: 'high',
          transactions: 31,
          timeWindow: '12 minutes',
          locations: ['Sydney', 'Melbourne'],
          riskScore: 90,
        },
      ],
      geographic: [
        {
          id: 'GEO-AUS-001',
          title: 'Perth to Sydney Sprint',
          description: 'Cross-continent transactions',
          severity: 'high',
          transactions: 2,
          timeWindow: '3 hours',
          locations: ['Perth, WA', 'Sydney, NSW'],
          riskScore: 93,
        },
      ],
      behavioral: [
        {
          id: 'BEH-AUS-001',
          title: 'Bushfire Emergency Pattern',
          description: 'Unusual emergency supply purchases',
          severity: 'medium',
          transactions: 14,
          timeWindow: '1 day',
          locations: ['Rural NSW', 'Rural VIC'],
          riskScore: 76,
        },
      ],
      temporal: [
        {
          id: 'TEM-AUS-001',
          title: 'AFL Grand Final Anomaly',
          description: 'Unusual activity during AFL Grand Final',
          severity: 'low',
          transactions: 9,
          timeWindow: 'Saturday afternoon',
          locations: ['Melbourne', 'Adelaide'],
          riskScore: 41,
        },
      ],
    },
    singapore: {
      velocity: [
        {
          id: 'VEL-SG-001',
          title: 'PayNow Burst Pattern',
          description: 'Rapid PayNow transactions',
          severity: 'critical',
          transactions: 42,
          timeWindow: '6 minutes',
          locations: ['Central Singapore'],
          riskScore: 95,
        },
      ],
      geographic: [
        {
          id: 'GEO-SG-001',
          title: 'Cross-Border Anomaly',
          description: 'Singapore-Malaysia rapid transactions',
          severity: 'high',
          transactions: 3,
          timeWindow: '1 hour',
          locations: ['Singapore', 'Johor Bahru'],
          riskScore: 87,
        },
      ],
      behavioral: [
        {
          id: 'BEH-SG-001',
          title: 'CNY Shopping Spree',
          description: 'Unusual Chinese New Year spending',
          severity: 'medium',
          transactions: 16,
          timeWindow: '3 days',
          locations: ['Orchard Road', 'Chinatown'],
          riskScore: 69,
        },
      ],
      temporal: [
        {
          id: 'TEM-SG-001',
          title: 'Hawker Center Night Pattern',
          description: 'Late night hawker center transactions',
          severity: 'low',
          transactions: 7,
          timeWindow: '11 PM - 2 AM',
          locations: ['Various hawker centers'],
          riskScore: 35,
        },
      ],
    },
    japan: {
      velocity: [
        {
          id: 'VEL-JP-001',
          title: 'IC Card Clone Burst',
          description: 'Multiple IC card transactions simultaneously',
          severity: 'critical',
          transactions: 38,
          timeWindow: '4 minutes',
          locations: ['Tokyo', 'Osaka'],
          riskScore: 97,
        },
      ],
      geographic: [
        {
          id: 'GEO-JP-001',
          title: 'Hokkaido to Okinawa',
          description: 'Extreme north to south transactions',
          severity: 'critical',
          transactions: 2,
          timeWindow: '2 hours',
          locations: ['Sapporo', 'Naha'],
          riskScore: 98,
        },
      ],
      behavioral: [
        {
          id: 'BEH-JP-001',
          title: 'Golden Week Anomaly',
          description: 'Unusual Golden Week spending patterns',
          severity: 'medium',
          transactions: 21,
          timeWindow: '1 week',
          locations: ['Tokyo', 'Kyoto', 'Osaka'],
          riskScore: 73,
        },
      ],
      temporal: [
        {
          id: 'TEM-JP-001',
          title: 'Pachinko Parlor Pattern',
          description: 'Late night pachinko transactions',
          severity: 'medium',
          transactions: 11,
          timeWindow: '10 PM - 2 AM',
          locations: ['Shibuya', 'Shinjuku'],
          riskScore: 67,
        },
      ],
    },
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-400 bg-red-400 bg-opacity-20';
      case 'high': return 'text-orange-400 bg-orange-400 bg-opacity-20';
      case 'medium': return 'text-yellow-400 bg-yellow-400 bg-opacity-20';
      case 'low': return 'text-blue-400 bg-blue-400 bg-opacity-20';
      default: return 'text-gray-400 bg-gray-400 bg-opacity-20';
    }
  };

  const currentPatterns = regionPatterns[selectedRegion as keyof typeof regionPatterns]?.[selectedPattern as keyof typeof regionPatterns.global] || 
                          regionPatterns.global[selectedPattern as keyof typeof regionPatterns.global] || [];
  const selectedPatternData = patterns.find(p => p.id === selectedPattern);
  const currencySymbol = currencies[selectedCurrency as keyof typeof currencies]?.symbol || '$';

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center space-x-2">
          <Filter className="h-6 w-6 text-purple-400" />
          <span>Pattern Analysis</span>
        </h2>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-gray-400">
            {selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()} • {selectedCurrency}
          </div>
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-gray-600 focus:border-blue-500 focus:outline-none"
          >
            <option value="1d">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </select>
        </div>
      </div>

      {/* Pattern Type Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {patterns.map((pattern) => (
          <div
            key={pattern.id}
            className={`bg-gray-700 rounded-lg p-4 border cursor-pointer transition-all duration-200 hover:bg-gray-600 ${
              selectedPattern === pattern.id
                ? 'border-blue-500 bg-blue-500 bg-opacity-10'
                : 'border-gray-600'
            }`}
            onClick={() => setSelectedPattern(pattern.id)}
          >
            <div className="flex items-center space-x-3 mb-3">
              <div className="p-2 bg-gray-600 rounded-lg">
                <pattern.icon className="h-5 w-5 text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-white">{pattern.name}</h3>
                <p className="text-xs text-gray-400">{pattern.description}</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div>
                <span className="text-gray-400">Cases:</span>
                <span className="text-white ml-1 font-medium">{pattern.detectedCases}</span>
              </div>
              <div>
                <span className="text-gray-400">Accuracy:</span>
                <span className="text-green-400 ml-1 font-medium">{pattern.accuracy}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Selected Pattern Details */}
      {selectedPatternData && (
        <div className="bg-gray-700 rounded-lg p-6 border border-gray-600 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-semibold flex items-center space-x-2">
              <selectedPatternData.icon className="h-6 w-6 text-blue-400" />
              <span>{selectedPatternData.name} - {selectedRegion === 'global' ? 'Global' : selectedRegion.toUpperCase()}</span>
            </h3>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <Eye className="h-4 w-4 text-gray-400" />
                <span className="text-gray-400">Active Monitoring</span>
              </div>
              <div className="bg-green-500 bg-opacity-20 text-green-400 px-3 py-1 rounded-full">
                {selectedPatternData.accuracy}% Accuracy
              </div>
            </div>
          </div>
          <p className="text-gray-300 mb-4">{selectedPatternData.description}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-600 rounded-lg p-4">
              <div className="text-2xl font-bold text-white mb-1">
                {selectedPatternData.detectedCases}
              </div>
              <div className="text-sm text-gray-400">Cases Detected</div>
            </div>
            <div className="bg-gray-600 rounded-lg p-4">
              <div className="text-2xl font-bold text-blue-400 mb-1">
                {currentPatterns.length}
              </div>
              <div className="text-sm text-gray-400">Active Patterns</div>
            </div>
            <div className="bg-gray-600 rounded-lg p-4">
              <div className="text-2xl font-bold text-green-400 mb-1">
                {selectedPatternData.accuracy}%
              </div>
              <div className="text-sm text-gray-400">Detection Accuracy</div>
            </div>
          </div>
        </div>
      )}

      {/* Detected Patterns List */}
      <div className="bg-gray-700 rounded-lg p-6 border border-gray-600">
        <h3 className="text-lg font-semibold mb-4 flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5 text-yellow-400" />
          <span>Detected Patterns ({currencySymbol})</span>
        </h3>
        
        <div className="space-y-4">
          {currentPatterns.map((pattern) => (
            <div
              key={pattern.id}
              className="bg-gray-600 rounded-lg p-4 border border-gray-500 hover:border-gray-400 transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h4 className="text-lg font-medium text-white">{pattern.title}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(pattern.severity)}`}>
                      {pattern.severity.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-gray-300 mb-3">{pattern.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Transactions:</span>
                      <span className="text-white ml-2 font-medium">{pattern.transactions}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Time Window:</span>
                      <span className="text-white ml-2 font-medium">{pattern.timeWindow}</span>
                    </div>
                    <div>
                      <span className="text-gray-400">Locations:</span>
                      <span className="text-white ml-2 font-medium">
                        {pattern.locations.join(', ')}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-400">Risk Score:</span>
                      <span className="text-red-400 ml-2 font-medium">{pattern.riskScore}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 ml-4">
                  <div className="text-right">
                    <div className="text-sm text-gray-400 mb-1">Risk Score</div>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 bg-gray-700 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            pattern.riskScore >= 90 ? 'bg-red-400' :
                            pattern.riskScore >= 70 ? 'bg-orange-400' :
                            pattern.riskScore >= 50 ? 'bg-yellow-400' : 'bg-green-400'
                          }`}
                          style={{ width: `${pattern.riskScore}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{pattern.riskScore}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-500">
                <div className="text-sm text-gray-400">
                  Pattern ID: {pattern.id}
                </div>
                <div className="flex items-center space-x-2">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                    Investigate
                  </button>
                  <button className="bg-gray-500 hover:bg-gray-400 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PatternAnalysis;